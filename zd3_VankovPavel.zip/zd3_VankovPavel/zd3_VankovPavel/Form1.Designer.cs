﻿namespace zd3_VankovPavel
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblStoreName;
        private System.Windows.Forms.TextBox txtStoreName;
        private System.Windows.Forms.Label lblSalesCount;
        private System.Windows.Forms.TextBox txtSalesCount;
        private System.Windows.Forms.Label lblRevenue;
        private System.Windows.Forms.TextBox txtRevenue;
        private System.Windows.Forms.Button btnAddStore;

        private System.Windows.Forms.Label lblChainName;
        private System.Windows.Forms.TextBox txtChainName;
        private System.Windows.Forms.Label lblChainSales;
        private System.Windows.Forms.TextBox txtChainSales;
        private System.Windows.Forms.Label lblChainRevenue;
        private System.Windows.Forms.TextBox txtChainRevenue;
        private System.Windows.Forms.Label lblCustomers;
        private System.Windows.Forms.TextBox txtCustomers;
        private System.Windows.Forms.Label lblRegion;
        private System.Windows.Forms.TextBox txtRegion;
        private System.Windows.Forms.Button btnAddChain;

        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ListBox listBoxResults;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblStoreName = new System.Windows.Forms.Label();
            this.txtStoreName = new System.Windows.Forms.TextBox();
            this.lblSalesCount = new System.Windows.Forms.Label();
            this.txtSalesCount = new System.Windows.Forms.TextBox();
            this.lblRevenue = new System.Windows.Forms.Label();
            this.txtRevenue = new System.Windows.Forms.TextBox();
            this.btnAddStore = new System.Windows.Forms.Button();
            this.lblChainName = new System.Windows.Forms.Label();
            this.txtChainName = new System.Windows.Forms.TextBox();
            this.lblChainSales = new System.Windows.Forms.Label();
            this.txtChainSales = new System.Windows.Forms.TextBox();
            this.lblChainRevenue = new System.Windows.Forms.Label();
            this.txtChainRevenue = new System.Windows.Forms.TextBox();
            this.lblCustomers = new System.Windows.Forms.Label();
            this.txtCustomers = new System.Windows.Forms.TextBox();
            this.lblRegion = new System.Windows.Forms.Label();
            this.txtRegion = new System.Windows.Forms.TextBox();
            this.btnAddChain = new System.Windows.Forms.Button();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.listBoxResults = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblStoreName
            // 
            this.lblStoreName.AutoSize = true;
            this.lblStoreName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblStoreName.Location = new System.Drawing.Point(12, 15);
            this.lblStoreName.Name = "lblStoreName";
            this.lblStoreName.Size = new System.Drawing.Size(160, 16);
            this.lblStoreName.TabIndex = 0;
            this.lblStoreName.Text = "Название магазина:";
            // 
            // txtStoreName
            // 
            this.txtStoreName.Location = new System.Drawing.Point(224, 9);
            this.txtStoreName.Name = "txtStoreName";
            this.txtStoreName.Size = new System.Drawing.Size(200, 22);
            this.txtStoreName.TabIndex = 1;
            // 
            // lblSalesCount
            // 
            this.lblSalesCount.AutoSize = true;
            this.lblSalesCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSalesCount.Location = new System.Drawing.Point(12, 43);
            this.lblSalesCount.Name = "lblSalesCount";
            this.lblSalesCount.Size = new System.Drawing.Size(158, 16);
            this.lblSalesCount.TabIndex = 2;
            this.lblSalesCount.Text = "Количество продаж:";
            // 
            // txtSalesCount
            // 
            this.txtSalesCount.Location = new System.Drawing.Point(224, 37);
            this.txtSalesCount.Name = "txtSalesCount";
            this.txtSalesCount.Size = new System.Drawing.Size(200, 22);
            this.txtSalesCount.TabIndex = 3;
            // 
            // lblRevenue
            // 
            this.lblRevenue.AutoSize = true;
            this.lblRevenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblRevenue.Location = new System.Drawing.Point(12, 71);
            this.lblRevenue.Name = "lblRevenue";
            this.lblRevenue.Size = new System.Drawing.Size(75, 16);
            this.lblRevenue.TabIndex = 4;
            this.lblRevenue.Text = "Выручка:";
            // 
            // txtRevenue
            // 
            this.txtRevenue.Location = new System.Drawing.Point(224, 65);
            this.txtRevenue.Name = "txtRevenue";
            this.txtRevenue.Size = new System.Drawing.Size(200, 22);
            this.txtRevenue.TabIndex = 5;
            // 
            // btnAddStore
            // 
            this.btnAddStore.Location = new System.Drawing.Point(224, 93);
            this.btnAddStore.Name = "btnAddStore";
            this.btnAddStore.Size = new System.Drawing.Size(200, 30);
            this.btnAddStore.TabIndex = 6;
            this.btnAddStore.Text = "Добавить магазин";
            this.btnAddStore.UseVisualStyleBackColor = true;
            this.btnAddStore.Click += new System.EventHandler(this.btnAddStore_Click);
            // 
            // lblChainName
            // 
            this.lblChainName.AutoSize = true;
            this.lblChainName.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblChainName.Location = new System.Drawing.Point(12, 140);
            this.lblChainName.Name = "lblChainName";
            this.lblChainName.Size = new System.Drawing.Size(123, 16);
            this.lblChainName.TabIndex = 7;
            this.lblChainName.Text = "Название сети:";
            // 
            // txtChainName
            // 
            this.txtChainName.Location = new System.Drawing.Point(224, 134);
            this.txtChainName.Name = "txtChainName";
            this.txtChainName.Size = new System.Drawing.Size(200, 22);
            this.txtChainName.TabIndex = 8;
            // 
            // lblChainSales
            // 
            this.lblChainSales.AutoSize = true;
            this.lblChainSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblChainSales.Location = new System.Drawing.Point(12, 168);
            this.lblChainSales.Name = "lblChainSales";
            this.lblChainSales.Size = new System.Drawing.Size(158, 16);
            this.lblChainSales.TabIndex = 9;
            this.lblChainSales.Text = "Количество продаж:";
            // 
            // txtChainSales
            // 
            this.txtChainSales.Location = new System.Drawing.Point(224, 162);
            this.txtChainSales.Name = "txtChainSales";
            this.txtChainSales.Size = new System.Drawing.Size(200, 22);
            this.txtChainSales.TabIndex = 10;
            // 
            // lblChainRevenue
            // 
            this.lblChainRevenue.AutoSize = true;
            this.lblChainRevenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblChainRevenue.Location = new System.Drawing.Point(12, 196);
            this.lblChainRevenue.Name = "lblChainRevenue";
            this.lblChainRevenue.Size = new System.Drawing.Size(75, 16);
            this.lblChainRevenue.TabIndex = 11;
            this.lblChainRevenue.Text = "Выручка:";
            // 
            // txtChainRevenue
            // 
            this.txtChainRevenue.Location = new System.Drawing.Point(224, 190);
            this.txtChainRevenue.Name = "txtChainRevenue";
            this.txtChainRevenue.Size = new System.Drawing.Size(200, 22);
            this.txtChainRevenue.TabIndex = 12;
            // 
            // lblCustomers
            // 
            this.lblCustomers.AutoSize = true;
            this.lblCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCustomers.Location = new System.Drawing.Point(12, 224);
            this.lblCustomers.Name = "lblCustomers";
            this.lblCustomers.Size = new System.Drawing.Size(200, 16);
            this.lblCustomers.TabIndex = 13;
            this.lblCustomers.Text = "Количество покупателей:";
            // 
            // txtCustomers
            // 
            this.txtCustomers.Location = new System.Drawing.Point(224, 218);
            this.txtCustomers.Name = "txtCustomers";
            this.txtCustomers.Size = new System.Drawing.Size(200, 22);
            this.txtCustomers.TabIndex = 14;
            // 
            // lblRegion
            // 
            this.lblRegion.AutoSize = true;
            this.lblRegion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblRegion.Location = new System.Drawing.Point(12, 252);
            this.lblRegion.Name = "lblRegion";
            this.lblRegion.Size = new System.Drawing.Size(64, 16);
            this.lblRegion.TabIndex = 15;
            this.lblRegion.Text = "Регион:";
            // 
            // txtRegion
            // 
            this.txtRegion.Location = new System.Drawing.Point(224, 246);
            this.txtRegion.Name = "txtRegion";
            this.txtRegion.Size = new System.Drawing.Size(200, 22);
            this.txtRegion.TabIndex = 16;
            // 
            // btnAddChain
            // 
            this.btnAddChain.Location = new System.Drawing.Point(224, 274);
            this.btnAddChain.Name = "btnAddChain";
            this.btnAddChain.Size = new System.Drawing.Size(200, 30);
            this.btnAddChain.TabIndex = 17;
            this.btnAddChain.Text = "Добавить сеть";
            this.btnAddChain.UseVisualStyleBackColor = true;
            this.btnAddChain.Click += new System.EventHandler(this.btnAddChain_Click);
            // 
            // btnShowAll
            // 
            this.btnShowAll.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnShowAll.Location = new System.Drawing.Point(12, 320);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new System.Drawing.Size(150, 30);
            this.btnShowAll.TabIndex = 18;
            this.btnShowAll.Text = "Показать все";
            this.btnShowAll.UseVisualStyleBackColor = false;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnClear.Location = new System.Drawing.Point(268, 317);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(150, 30);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Очистить";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // listBoxResults
            // 
            this.listBoxResults.FormattingEnabled = true;
            this.listBoxResults.HorizontalScrollbar = true;
            this.listBoxResults.ItemHeight = 16;
            this.listBoxResults.Location = new System.Drawing.Point(450, 9);
            this.listBoxResults.Name = "listBoxResults";
            this.listBoxResults.ScrollAlwaysVisible = true;
            this.listBoxResults.Size = new System.Drawing.Size(450, 340);
            this.listBoxResults.TabIndex = 20;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(915, 354);
            this.Controls.Add(this.listBoxResults);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.btnAddChain);
            this.Controls.Add(this.txtRegion);
            this.Controls.Add(this.lblRegion);
            this.Controls.Add(this.txtCustomers);
            this.Controls.Add(this.lblCustomers);
            this.Controls.Add(this.txtChainRevenue);
            this.Controls.Add(this.lblChainRevenue);
            this.Controls.Add(this.txtChainSales);
            this.Controls.Add(this.lblChainSales);
            this.Controls.Add(this.txtChainName);
            this.Controls.Add(this.lblChainName);
            this.Controls.Add(this.btnAddStore);
            this.Controls.Add(this.txtRevenue);
            this.Controls.Add(this.lblRevenue);
            this.Controls.Add(this.txtSalesCount);
            this.Controls.Add(this.lblSalesCount);
            this.Controls.Add(this.txtStoreName);
            this.Controls.Add(this.lblStoreName);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Управление сетью магазинов";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}