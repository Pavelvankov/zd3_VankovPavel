﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

using ClassLibrary1;

namespace zd3_VankovPavel
{
    public partial class Form1 : Form
    {
        private List<Store> stores = new List<Store>();  // Обычные магазины
        private Dictionary<string, ChainStore> chainStores = new Dictionary<string, ChainStore>();  // Сети магазинов

        public Form1()
        {
            InitializeComponent();
        }

        // Добавить обычный магазин
        private void btnAddStore_Click(object sender, EventArgs e)
        {
            try
            {
                var store = new Store(
                    txtStoreName.Text,
                    int.Parse(txtSalesCount.Text),
                    double.Parse(txtRevenue.Text));

                stores.Add(store);
                MessageBox.Show("Обычный магазин добавлен!");
                ClearStoreFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        // Добавить сеть магазинов
        private void btnAddChain_Click(object sender, EventArgs e)
        {
            try
            {
                var chain = new ChainStore(
                    txtChainName.Text,
                    int.Parse(txtChainSales.Text),
                    double.Parse(txtChainRevenue.Text),
                    int.Parse(txtCustomers.Text),
                    txtRegion.Text);

                chainStores.Add(chain.Name, chain);
                MessageBox.Show("Сеть магазинов добавлена!");
                ClearChainFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        // Показать все магазины
        private void btnShowAll_Click(object sender, EventArgs e)
        {
            listBoxResults.Items.Clear();

            // Вывод обычных магазинов
            foreach (var store in stores)
            {
                listBoxResults.Items.Add($"МАГАЗИН: {store.Info()}");
            }

            // Вывод сетей магазинов
            foreach (var chain in chainStores.Values)
            {
                listBoxResults.Items.Add($"СЕТЬ: {chain.Info()}");
            }

            var highQualityStores = stores.Where(s => s.Quality() > 1000).ToList();
            var highQualityChains = chainStores.Values.Where(c => c.Quality() > 1000).ToList();
        }

        // Очистить список
        private void btnClear_Click(object sender, EventArgs e)
        {
            listBoxResults.Items.Clear();
        }

        // Очистить поля магазина
        private void ClearStoreFields()
        {
            txtStoreName.Clear();
            txtSalesCount.Clear();
            txtRevenue.Clear();
        }

        // Очистить поля сети
        private void ClearChainFields()
        {
            txtChainName.Clear();
            txtChainSales.Clear();
            txtChainRevenue.Clear();
            txtCustomers.Clear();
            txtRegion.Clear();
        }
    }
}